#include<stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAX_SIZE 10

int main(void) {
    int i;
	int* a;
	int size = 30;

	



    srand(time(NULL));
    printf("-----Using array-----\n");
    for (i = 1; i <= size; i++) {
        if (i % 2 == 0)
            printf("[%d] : push %d\n", i, rand() % 100 + 1);
        else if (i % 2 == 1)
            printf("[%d] : pop %d\n", i, rand() % 100 + 1);

        a = (int*)malloc(size * sizeof(int));




        free(a);

    }
        return 0;
    
}


	